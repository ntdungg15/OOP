public interface GeometricObject {
    public String getInfo();

    public double getArea();

    public double getPerimeter();
}
