import java.io.FileNotFoundException;
import java.io.IOException;


public class Week8Task2 {
    public void ioEx() throws IOException {
        throw new IOException("Lỗi IO");
    }

    public void fileNotFoundEx() throws FileNotFoundException {
        throw new FileNotFoundException("Lỗi File Not Found");
    }

    public void arithmeticEx() {
        int result = 5 / 0;
    }

    public void arrayIndexOutOfBoundsEx() {
        int[] arr = new int[3];
        int value = arr[5];
    }

    public void nullPointerEx() {
        String str = null;
        int length = str.length();
    }

    /**
     * ioExTest .
     */
    public String ioExTest() {
        try {
            ioEx();
        } catch (IOException e) {
            return e.getMessage();
        }
        return "no error";
    }

    /**
     * fileNotFoundExTest .
     */
    public String fileNotFoundExTest() {
        try {
            fileNotFoundEx();
        } catch (FileNotFoundException e) {
            return e.getMessage();
        }
        return "no error";
    }

    /**
     * arithmeticExTest .
     */
    public String arithmeticExTest() {
        try {
            arithmeticEx();
        } catch (ArithmeticException e) {
            return "Lỗi Arithmetic";
        }
        return "no error";
    }

    /**
     * arrayIndexOutOfBoundsExTest .
     */
    public String arrayIndexOutOfBoundsExTest() {
        try {
            arrayIndexOutOfBoundsEx();
        } catch (ArrayIndexOutOfBoundsException e) {
            return "Lỗi Array Index Out of Bounds";
        }
        return "no error";
    }

    /**
     * nullPointerExTest .
     */
    public String nullPointerExTest() {
        try {
            nullPointerEx();
        } catch (NullPointerException e) {
            return "Lỗi Null Pointer";
        }
        return "no error";
    }

    /**
     * main .
     */
    public static void main(String[] args) {
        Week8Task2 task = new Week8Task2();
        System.out.println(task.ioExTest());
        System.out.println(task.fileNotFoundExTest());
        System.out.println(task.arithmeticExTest());
        System.out.println(task.arrayIndexOutOfBoundsExTest());
        System.out.println(task.nullPointerExTest());
    }
}
